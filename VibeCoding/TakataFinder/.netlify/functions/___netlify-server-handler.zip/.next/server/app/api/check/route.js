var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/check/route.js")
R.c("server/chunks/[root-of-the-server]__09a746a1._.js")
R.c("server/chunks/[root-of-the-server]__31f74882._.js")
R.m(18416)
R.m(99989)
module.exports=R.m(99989).exports
